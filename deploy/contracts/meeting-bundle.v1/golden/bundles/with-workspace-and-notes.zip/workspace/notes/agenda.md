# Agenda

1. Release checklist
2. Migration plan
