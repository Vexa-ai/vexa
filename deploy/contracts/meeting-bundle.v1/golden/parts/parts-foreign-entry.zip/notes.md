---
type: meeting
meeting: 4242
title: Release sync
---

# Release sync

<!-- vexa:transcript meeting=4242 -->

<!-- meeting:decisions:start -->
- ship 0.13
<!-- meeting:decisions:end -->
